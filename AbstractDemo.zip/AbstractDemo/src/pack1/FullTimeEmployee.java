package pack1;

public class FullTimeEmployee extends Employee{
	private int overTimeHrs;
    public FullTimeEmployee()
       {overTimeHrs=0;}
    public FullTimeEmployee(int id,String name,double salary,int overTimeHrs)
    {super(id,name,salary);
     this.overTimeHrs=overTimeHrs;
     }

	public int getOverTimeHrs() {
		return overTimeHrs;
	}

	public void setOverTimeHrs(int overTimeHrs) {
		if(overTimeHrs<=20)
		    this.overTimeHrs = overTimeHrs;
	}
	public void printSalary()
	{   double salary=getSalary();
		System.out.println("Employee Total Salary : "+salary*overTimeHrs*1000);
    }
	

}
