package pack1;

public abstract class Employee {
	private int id=1;
	private String name="";
	private double salary=0.0;
	 public Employee()
	 {id=1;name="";salary=0.0;
	 }
	 public Employee(int id,String name)
	 {this.id=id;this.name=name;
	 }
	 public Employee(int id,String name,double salary)
	 {this.id=id;this.name=name;this.salary=salary;
	 }
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public abstract void printSalary();
	public void displayDetails()
	{System.out.println("Employee Id :"+id);
	 System.out.println("Employee Name :"+name);
	 printSalary();
	}
	

}

