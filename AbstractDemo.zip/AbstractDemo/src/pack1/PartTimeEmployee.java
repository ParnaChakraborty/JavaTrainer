package pack1;

public class PartTimeEmployee extends Employee{
	private int noOfDays;
	private int chargePerHr;
    public PartTimeEmployee()
       {noOfDays=0;
        chargePerHr=0;
       }
       
    public PartTimeEmployee(int id,String name,int noOfDays,int chargePerHr)
    {super(id,name);
     this.noOfDays=noOfDays;
     this.chargePerHr=chargePerHr;
     }

     
	
	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public int getChargePerHr() {
		return chargePerHr;
	}

	public void setChargePerHr(int chargePerHr) {
		this.chargePerHr = chargePerHr;
	}

	public void printSalary()
	{   
		System.out.println("Employee Total Salary : "+noOfDays*chargePerHr);
    } 
}